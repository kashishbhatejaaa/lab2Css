
<script>

  function changeText() {
  constpara = document.getElementById('myParagraph')
  para.innerText = 'Text changed';

</script>
